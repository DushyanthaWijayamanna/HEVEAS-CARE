package com.apiit.fyphc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class SymptomsActivity extends AppCompatActivity {
    private Toolbar toolbar;

    private FloatingActionButton fabBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);

        fabBtn = findViewById(R.id.fab_btn);


        toolbar = findViewById(R.id.toolbar_home);
        setSupportActionBar(toolbar);
        FragmentManager fragmentManager = getSupportFragmentManager();
        Intent intent = getIntent();
        String diseaseName = intent.getStringExtra("nameFormResult");
        System.out.println(diseaseName+"***********************");
        if ("birds eyes".equals(diseaseName)){
            getSupportActionBar().setTitle("Symptoms of " + "Birds eys");
        } else if ("colletorichum leaf disease".equals(diseaseName)) {
            getSupportActionBar().setTitle("Symptoms of " + "Colletorichum disease");
        }
        else {
            getSupportActionBar().setTitle("Symptoms of " + diseaseName);
        }
        if ("Corynespora".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerViewSymptoms, CorynesporaSymptoms.class, null).
                    setReorderingAllowed(true).addToBackStack("namesymptoms").commit();
        } else if ("birds eyes".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerViewSymptoms,BirdseyeSymptoms.class, null).
                    setReorderingAllowed(true).addToBackStack("bsymptoms").commit();
        } else if ("Pesta".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerViewSymptoms,PestaSymptoms.class, null).
                    setReorderingAllowed(true).addToBackStack("psymptoms").commit();
        } else if ("colletorichum leaf disease".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerViewSymptoms,CorynesporaSymptoms.class, null).
                    setReorderingAllowed(true).addToBackStack("Csymptoms").commit();
        }
        else if ("Powdery mildew".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerViewSymptoms,PowderymildewSymptoms.class, null).
                    setReorderingAllowed(true).addToBackStack("Pwsymptoms").commit();
        }


        fabBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SymptomsActivity.this, HomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); // Add this line
                startActivity(intent);
            }
        });
    }
}