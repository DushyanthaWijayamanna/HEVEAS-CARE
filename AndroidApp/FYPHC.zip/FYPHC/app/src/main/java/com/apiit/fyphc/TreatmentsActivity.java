package com.apiit.fyphc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class TreatmentsActivity extends AppCompatActivity {

    //TextView dName;

    private Toolbar toolbar;

    private FloatingActionButton fabBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treatments);
        //dName = findViewById(R.id.dName);
        fabBtn = findViewById(R.id.fab_btn);
        toolbar = findViewById(R.id.toolbar_home);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();
        String diseaseName = intent.getStringExtra("nameFormResult");
        if ("birds eyes".equals(diseaseName)){
            getSupportActionBar().setTitle("Treatments for " + "Birds eys");
        } else if ("colletorichum leaf disease".equals(diseaseName)) {
            getSupportActionBar().setTitle("Treatments for " + "Colletorichum disease");
        }
        else {
            getSupportActionBar().setTitle("Treatments for " + diseaseName);
        }

        FragmentManager fragmentManager = getSupportFragmentManager();

        if ("Corynespora".equals(diseaseName)) {
            // Load the first fragment into the container
            //dName.setText("Treatments for " + diseaseName);
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, CorynesporaFragment.class, null).
                    setReorderingAllowed(true).addToBackStack("CorynesporaFragment").commit();
        } else if ("birds eyes".equals(diseaseName))
        {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, birds_eye_treatments.class, null).
                    setReorderingAllowed(true).addToBackStack("birds_eye_treatments").commit();
        } else if ("Pesta".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, pestaTreatments.class, null).
                    setReorderingAllowed(true).addToBackStack("pestaTreatments").commit();
        } else if ("colletorichum leaf disease".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, colletorichumTreatments.class, null).
                    setReorderingAllowed(true).addToBackStack("colletorichumTreatments").commit();
        } else if ("Powdery mildew".equals(diseaseName)) {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, PowderymildewTreatments.class, null).
                    setReorderingAllowed(true).addToBackStack("PowderymildewTreatments").commit();
        }
        fabBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TreatmentsActivity.this, HomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); // Add this line
                startActivity(intent);
            }
        });

    }
}