package com.apiit.fyphc;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.apiit.fyphc.ml.FinalModel4;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.DateFormat;
import java.util.Date;

public class HomeActivity extends AppCompatActivity {


    private Toolbar toolbar;

    TextView result, confidenceRate;
    ImageView imageView;

    public String nameFormResult;

    Button camera,gallery,treat,syp;

    private FirebaseAuth mAuth;

    int imageSize = 224;




    private FloatingActionButton fabBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        toolbar = findViewById(R.id.toolbar_home);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("HEVEA’S CARE ");

        camera=findViewById(R.id.camera);
        confidenceRate = findViewById(R.id.confidence);
        mAuth=FirebaseAuth.getInstance();


        gallery=findViewById(R.id.gallery);
        result=findViewById(R.id.result);
        imageView=findViewById(R.id.imageView);
        treat=findViewById(R.id.treat);
        syp=findViewById(R.id.syp);




        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //launch camera if we have permission
                if (checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, 3);
                } else {
                    //request camera permission if we don't have
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, 100);
                }
            }
        });
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent=new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(cameraIntent,1);
            }
        });


           result.addTextChangedListener(new TextWatcher() {
               @Override
               public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

               }

               @Override
               public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                 String resultText=charSequence.toString();
                 if(resultText.isEmpty() || "Invalid Object".equals(resultText) ){
                     camera.setVisibility(View.VISIBLE);
                     gallery.setVisibility(View.VISIBLE);
                     treat.setVisibility(View.GONE);
                     syp.setVisibility(View.GONE);

                 }
                 else {

                     camera.setVisibility(View.GONE);
                     gallery.setVisibility(View.GONE);
                     treat.setVisibility(View.VISIBLE);
                     syp.setVisibility(View.VISIBLE);
                 }
               }

               @Override
               public void afterTextChanged(Editable editable) {

               }
           });

           treat.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   nameFormResult=result.getText().toString();
                   Intent intent=new Intent(HomeActivity.this,TreatmentsActivity.class);
                   intent.putExtra("nameFormResult",nameFormResult);
                   startActivity(intent);
               }
           });

           syp.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   nameFormResult=result.getText().toString();
                   Intent intent=new Intent(HomeActivity.this,SymptomsActivity.class);
                   intent.putExtra("nameFormResult",nameFormResult);
                   startActivity(intent);
               }
           });



    }

    public void classifyImage(Bitmap image){
        try {
            FinalModel4 model =   FinalModel4.newInstance(getApplicationContext());
            // Creates inputs for reference.
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 224, 224, 3}, DataType.FLOAT32);
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * imageSize * imageSize * 3);
            byteBuffer.order(ByteOrder.nativeOrder());
            // get 1D array of 224 * 224 pixels in image
            int [] intValues = new int[imageSize * imageSize];
            image.getPixels(intValues, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight());
            // iterate over pixels and extract R, G, and B values. Add to bytebuffer.
            int pixel = 0;
            for(int i = 0; i < imageSize; i++){
                for(int j = 0; j < imageSize; j++){
                    int val = intValues[pixel++]; // RGB
                    byteBuffer.putFloat(((val >> 16) & 0xFF) * (1.f / 255.f));
                    byteBuffer.putFloat(((val >> 8) & 0xFF) * (1.f / 255.f));
                    byteBuffer.putFloat((val & 0xFF) * (1.f / 255.f));
                }
            }
            //newly add missing code
            inputFeature0.loadBuffer(byteBuffer);

            // Runs model inference and gets result.
            FinalModel4.Outputs outputs = model.process(inputFeature0);

            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

            float[] confidences = outputFeature0.getFloatArray();


            // find the index of the class with the biggest confidence.
            int maxPos = 0;
            float maxConfidence = 0;
            for(int i = 0; i < confidences.length; i++){
                if(confidences[i] > maxConfidence){
                    maxConfidence = confidences[i];
                    maxPos = i;
                }
            }
            String[] classes={"Corynespora","Healthy","Other","Pesta","Powdery mildew","birds eyes","colletorichum leaf disease"};
            String maxConfidenceString = String.format("%s: %.1f%%", classes[maxPos], maxConfidence * 100);
            String maxConfidenceInvalidString = String.format("%s: %.1f%%", "Invalid Object", maxConfidence * 100);
            //float confidenceValue = Float.parseFloat(maxConfidenceString.split(":")[1].trim().replace("%", ""));
            if (classes[maxPos].equals("Other")) {
                result.setText("Invalid Object");
                result.requestFocus();
                confidenceRate.setText(maxConfidenceInvalidString);
            } else {
                result.setText(classes[maxPos]);
                confidenceRate.setText(maxConfidenceString);
            }
            // Releases model resources if no longer used.
            model.close();
        } catch (IOException e) {
            // TODO Handle the exception
        }

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(resultCode==RESULT_OK){
            if(requestCode == 3){//when user take picture from camera
                Bitmap image = (Bitmap) data.getExtras().get("data");
                int dimension=Math.min(image.getWidth(),image.getHeight());
                image= ThumbnailUtils.extractThumbnail(image,dimension,dimension);
                imageView.setImageBitmap(image);

                image=Bitmap.createScaledBitmap(image,imageSize,imageSize,false);//resize image
                classifyImage(image);
            }else{ //when user select picture from gallery
                Uri dat=data.getData();
                Bitmap image=null;
                try{
                    image = MediaStore.Images.Media.getBitmap(this.getContentResolver(), dat);
                }catch (IOException e){
                    e.printStackTrace();
                }

                imageView.setImageBitmap(image);
                image=Bitmap.createScaledBitmap(image,imageSize,imageSize,false);//resize image
                classifyImage(image);

            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.mainmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId(); // Get the resource ID

        if (itemId == R.id.logout){


                mAuth.signOut();
                startActivity(new Intent(getApplicationContext(),MainActivity.class));


        } else if (itemId == R.id.home) {
            Intent intent=new Intent(HomeActivity.this,HomeActivity.class);

            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}